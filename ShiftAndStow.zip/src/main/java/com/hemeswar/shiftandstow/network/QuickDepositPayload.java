package com.hemeswar.shiftandstow.network;

import com.hemeswar.shiftandstow.ShiftAndStow;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record QuickDepositPayload() implements CustomPayload {
    public static final CustomPayload.Id<QuickDepositPayload> ID = 
        new CustomPayload.Id<>(Identifier.of(ShiftAndStow.MOD_ID, "quick_deposit"));

    public static final PacketCodec<RegistryByteBuf, QuickDepositPayload> CODEC = 
        PacketCodec.unit(new QuickDepositPayload());

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
