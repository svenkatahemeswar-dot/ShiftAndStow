package com.hemeswar.shiftandstow;

import com.hemeswar.shiftandstow.network.QuickDepositPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class ShiftAndStow implements ModInitializer {
    public static final String MOD_ID = "shift_and_stow";

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(QuickDepositPayload.ID, QuickDepositPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(QuickDepositPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                QuickDepositLogic.performQuickDeposit(context.player());
            });
        });
    }
}
