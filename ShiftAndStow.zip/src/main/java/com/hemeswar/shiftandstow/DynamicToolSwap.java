package com.hemeswar.shiftandstow;

import com.hemeswar.shiftandstow.network.QuickDepositPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public class DynamicToolSwap implements ClientModInitializer {
    private static KeyBinding swapKey;
    private static KeyBinding stowKey;

    @Override
    public void onInitializeClient() {
        swapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.shiftandstow.swap_tool",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_R,
            "category.shiftandstow.general"
        ));

        stowKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.shiftandstow.stow_items",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_G,
            "category.shiftandstow.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;

            if (swapKey.wasPressed()) {
                trySwapTool(client);
            }

            if (stowKey.wasPressed()) {
                ClientPlayNetworking.send(new QuickDepositPayload());
            }
        });
    }

    private void trySwapTool(MinecraftClient client) {
        HitResult hit = client.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.BLOCK) return;

        BlockPos pos = ((BlockHitResult) hit).getBlockPos();
        BlockState state = client.world.getBlockState(pos);
        PlayerInventory inv = client.player.getInventory();

        int bestSlot = -1;
        float maxSpeed = 1.0f;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty()) {
                float speed = stack.getMiningSpeedMultiplier(state);
                if (speed > maxSpeed) {
                    maxSpeed = speed;
                    bestSlot = i;
                }
            }
        }

        if (bestSlot != -1) {
            inv.selectedSlot = bestSlot;
        }
    }
}
