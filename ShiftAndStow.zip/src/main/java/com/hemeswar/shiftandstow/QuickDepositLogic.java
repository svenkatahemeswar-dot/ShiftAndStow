package com.hemeswar.shiftandstow;

import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;

public class QuickDepositLogic {

    public static void performQuickDeposit(ServerPlayerEntity player) {
        if (!(player.currentScreenHandler instanceof GenericContainerScreenHandler container)) {
            return;
        }

        Inventory chestInventory = container.getInventory();
        var playerInventory = player.getInventory();

        for (int i = 9; i < 36; i++) {
            ItemStack playerStack = playerInventory.getStack(i);
            if (playerStack.isEmpty()) continue;

            if (chestContainsItem(chestInventory, playerStack)) {
                ItemStack remaining = depositStack(chestInventory, playerStack);
                playerInventory.setStack(i, remaining);
            }
        }
        player.currentScreenHandler.sendContentUpdates();
    }

    private static boolean chestContainsItem(Inventory chest, ItemStack stack) {
        for (int i = 0; i < chest.size(); i++) {
            ItemStack chestStack = chest.getStack(i);
            if (ItemStack.areItemsEqual(chestStack, stack)) {
                return true;
            }
        }
        return false;
    }

    private static ItemStack depositStack(Inventory chest, ItemStack stack) {
        ItemStack copy = stack.copy();
        
        for (int i = 0; i < chest.size(); i++) {
            ItemStack chestStack = chest.getStack(i);
            if (ItemStack.areItemsAndComponentsEqual(chestStack, copy)) {
                int transferable = Math.min(copy.getCount(), chestStack.getMaxCount() - chestStack.getCount());
                if (transferable > 0) {
                    chestStack.increment(transferable);
                    copy.decrement(transferable);
                    if (copy.isEmpty()) return ItemStack.EMPTY;
                }
            }
        }

        for (int i = 0; i < chest.size(); i++) {
            if (chest.getStack(i).isEmpty()) {
                chest.setStack(i, copy);
                return ItemStack.EMPTY;
            }
        }

        return copy;
    }
}
